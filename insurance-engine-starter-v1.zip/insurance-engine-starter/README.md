# Insurance Engine Starter v1.0

**Owner/operator:** Лъки Стар – 08 ЕООД (ЕИК 200339166)
**Initial broker:** ЕЙ ПИ БРОКЕРС ООД (ЕИК 207717424)
**Architecture:** multi-tenant B2B2C SaaS, commission-linked software service fees subject to legal review.

This is a **starter specification and executable reference validation module**, not a deployed production application. It does not include a working API server, UI, insurer APIs, authentication, or automated issuance.

## Contents
- `db/schema.sql`: PostgreSQL starter DDL and illustrative tenant RLS policies.
- `catalog/classes.json`: 18 non-life classes and draft life classes (requires legal classification review).
- `catalog/families.json`: customer-friendly families and class associations.
- `catalog/seed-organizations.json`: owner and initial broker identities.
- `rules/*.json`: universal, property and motor intake examples.
- `rules/engine.py`: deterministic reference rule evaluator (NOT the planned TypeScript production engine).
- `api/openapi.yaml`: initial OpenAPI contract.
- `tests/test_engine.py`: reference unit tests.
- `docs/ACCEPTANCE.md`: implementation backlog and compliance/security gates.

## Run tests
```bash
python -m unittest discover -s tests -v
```

## Important limitations
- Life-class taxonomy is a draft and must be verified against the current consolidated Bulgarian Insurance Code before production.
- EIK checksum validation deliberately fails closed until a verified implementation is added.
- RLS in the SQL is only an illustrative subset; implement complete policies for all tenant-owned resources.
- The PostgreSQL schema is an initial design, not a complete migration-ready production data model.
- No actual tariff calculations or insurer rates are provided; do not present generated quotes as real.
- Do not treat a technological service fee linked to broker commission as legally approved without counsel.
- Source code and third-party component rights must be contractually cleared for the platform owner.
