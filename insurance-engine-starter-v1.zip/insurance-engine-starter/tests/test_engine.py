import unittest, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'rules'))
from engine import evaluate, condition_matches
class EngineTests(unittest.TestCase):
 def setUp(self): self.schema=json.loads((ROOT/'rules'/'property-questionnaire.json').read_text(encoding='utf-8'))
 def test_conditional_visibility(self):
  self.assertTrue(condition_matches({'field':'construction','op':'eq','value':'STEEL'},{'construction':'STEEL'}))
  self.assertFalse(condition_matches({'field':'construction','op':'eq','value':'STEEL'},{'construction':'WOOD'}))
 def test_required(self):
  result=evaluate(self.schema, {'customer_type':'PERSON'})
  self.assertIn('object_type',result['errors'])
 def test_hidden_field_excluded(self):
  result=evaluate(self.schema,{'customer_type':'PERSON','construction':'WOOD','insulation_core':'PIR'})
  self.assertNotIn('insulation_core',result['sanitized_answers'])
 def test_claims_description_required(self):
  result=evaluate(self.schema,{'previous_claims':True})
  self.assertIn('claims_description',result['errors'])
 def test_negative_area_rejected(self):
  result=evaluate(self.schema,{'area_m2':-1})
  self.assertIn('below_minimum',result['errors']['area_m2'])
 def test_eik_fails_closed(self):
  result=evaluate(self.schema,{'customer_type':'COMPANY','company_eik':'207717424'})
  self.assertIn('eik_checksum_validator_not_implemented',result['errors']['company_eik'])
if __name__=='__main__': unittest.main()
