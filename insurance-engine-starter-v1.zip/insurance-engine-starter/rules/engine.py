"""Deterministic reference evaluator; production implementation should be in TypeScript."""
import re
from decimal import Decimal, InvalidOperation

def condition_matches(condition, answers):
    if not condition: return True
    if 'all' in condition: return all(condition_matches(c, answers) for c in condition['all'])
    if 'any' in condition: return any(condition_matches(c, answers) for c in condition['any'])
    value=answers.get(condition['field'])
    if value is None: return False
    op=condition['op']; expected=condition['value']
    if op=='eq': return value==expected
    if op=='in': return value in expected
    if op=='neq': return value!=expected
    raise ValueError('Unsupported operator: '+op)

def evaluate(schema, answers):
    errors={}; active={}
    for field in schema['fields']:
        key=field['key']; visible=condition_matches(field.get('visibleWhen'),answers)
        if not visible: continue
        active[key]=True
        required=field.get('required',False) or ('requiredWhen' in field and condition_matches(field['requiredWhen'],answers))
        value=answers.get(key)
        if value is None or value=='':
            if required: errors.setdefault(key,[]).append('required')
            continue
        kind=field['type']
        if kind=='decimal':
            try: num=Decimal(str(value))
            except (InvalidOperation,ValueError): errors.setdefault(key,[]).append('invalid_decimal');continue
            if not num.is_finite(): errors.setdefault(key,[]).append('invalid_decimal');continue
        if kind=='boolean' and type(value) is not bool: errors.setdefault(key,[]).append('invalid_boolean')
        if kind=='enum' and value not in field.get('options',[]): errors.setdefault(key,[]).append('invalid_option')
        if kind=='email' and (not isinstance(value,str) or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',value)):
            errors.setdefault(key,[]).append('invalid_email')
        for validator in field.get('validators',[]):
            vtype=validator['type']
            if vtype=='min' and kind=='decimal' and num<Decimal(str(validator['value'])): errors.setdefault(key,[]).append('below_minimum')
            if vtype=='minLength' and (not isinstance(value,str) or len(value)<validator['value']): errors.setdefault(key,[]).append('too_short')
            if vtype=='regex' and (not isinstance(value,str) or re.fullmatch(validator['pattern'],value) is None): errors.setdefault(key,[]).append('invalid_format')
            if vtype=='bulstat_checksum':
                # Fail closed until the official EIK/BULSTAT checksum validator is implemented.
                errors.setdefault(key,[]).append('eik_checksum_validator_not_implemented')
    return {'valid':not errors,'errors':errors,'active_fields':list(active),'sanitized_answers':{k:answers[k] for k in active if k in answers}}
