CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE organizations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), legal_name text NOT NULL,
 eik varchar(13) UNIQUE, kind text NOT NULL CHECK(kind IN ('PLATFORM_OPERATOR','BROKER')),
 status text NOT NULL DEFAULT 'PENDING', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), email text NOT NULL UNIQUE,
 password_hash text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE memberships (
 organization_id uuid NOT NULL REFERENCES organizations(id), user_id uuid NOT NULL REFERENCES users(id),
 role text NOT NULL CHECK(role IN ('BROKER_ADMIN','BROKER_AGENT','COMPLIANCE','SUPPORT')),
 PRIMARY KEY(organization_id,user_id,role)
);
CREATE TABLE insurance_classes (
 code text PRIMARY KEY, division text NOT NULL CHECK(division IN ('LIFE','NON_LIFE')),
 class_number int NOT NULL, label_bg text NOT NULL, UNIQUE(division,class_number)
);
CREATE TABLE product_families (key text PRIMARY KEY,label_bg text NOT NULL);
CREATE TABLE family_classes (
 family_key text NOT NULL REFERENCES product_families(key), class_code text NOT NULL REFERENCES insurance_classes(code),
 PRIMARY KEY(family_key,class_code)
);
CREATE TABLE insurers (id uuid PRIMARY KEY DEFAULT gen_random_uuid(),name text NOT NULL);
CREATE TABLE products (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), insurer_id uuid REFERENCES insurers(id),
 family_key text NOT NULL REFERENCES product_families(key), name text NOT NULL, active boolean NOT NULL DEFAULT false
);
CREATE TABLE product_versions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES products(id),
 version text NOT NULL, terms jsonb NOT NULL DEFAULT '{}'::jsonb, valid_from timestamptz,
 UNIQUE(product_id,version)
);
CREATE TABLE broker_product_access (
 broker_id uuid NOT NULL REFERENCES organizations(id), product_id uuid NOT NULL REFERENCES products(id),
 authorized boolean NOT NULL DEFAULT false, PRIMARY KEY(broker_id,product_id)
);
CREATE TABLE questionnaire_versions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), family_key text REFERENCES product_families(key),
 code text NOT NULL, version text NOT NULL, schema_json jsonb NOT NULL,
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','REVIEW','PUBLISHED','RETIRED')),
 UNIQUE(code,version)
);
CREATE TABLE customers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), broker_id uuid NOT NULL REFERENCES organizations(id),
 kind text NOT NULL CHECK(kind IN ('PERSON','COMPANY')), display_name text,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,broker_id)
);
CREATE TABLE applications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), broker_id uuid NOT NULL REFERENCES organizations(id),
 customer_id uuid NOT NULL, family_key text NOT NULL REFERENCES product_families(key),
 questionnaire_version_id uuid REFERENCES questionnaire_versions(id),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SUBMITTED','NEEDS_INFO','UNDER_REVIEW','QUOTING','OFFERED','ACCEPTED','DECLINED','CANCELLED','EXPIRED')),
 needs_summary jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(id,broker_id), FOREIGN KEY(customer_id,broker_id) REFERENCES customers(id,broker_id)
);
CREATE TABLE application_answers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), broker_id uuid NOT NULL,
 application_id uuid NOT NULL, field_key text NOT NULL, answer_json jsonb NOT NULL,
 revision int NOT NULL DEFAULT 1, recorded_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(application_id,broker_id) REFERENCES applications(id,broker_id),
 UNIQUE(application_id,field_key,revision)
);
CREATE TABLE quotes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), broker_id uuid NOT NULL,
 application_id uuid NOT NULL, product_version_id uuid REFERENCES product_versions(id),
 premium_eur numeric(14,2) CHECK(premium_eur>=0), details jsonb NOT NULL DEFAULT '{}'::jsonb,
 status text NOT NULL DEFAULT 'DRAFT', FOREIGN KEY(application_id,broker_id) REFERENCES applications(id,broker_id),
 UNIQUE(id,broker_id)
);
CREATE TABLE policies (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), broker_id uuid NOT NULL,
 quote_id uuid NOT NULL, policy_number text, issued_at timestamptz,
 status text NOT NULL DEFAULT 'PENDING', FOREIGN KEY(quote_id,broker_id) REFERENCES quotes(id,broker_id)
);
CREATE TABLE commission_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), broker_id uuid NOT NULL REFERENCES organizations(id),
 policy_id uuid NOT NULL REFERENCES policies(id), event_type text NOT NULL CHECK(event_type IN ('ACCRUED','RECEIVED','REVERSAL','SERVICE_FEE_INVOICED','SERVICE_FEE_PAID')),
 amount_eur numeric(14,2) NOT NULL, external_reference text,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(broker_id,event_type,external_reference)
);
CREATE TABLE documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), broker_id uuid NOT NULL REFERENCES organizations(id),
 application_id uuid, storage_key text NOT NULL, sha256 text NOT NULL,
 uploaded_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(application_id,broker_id) REFERENCES applications(id,broker_id)
);
CREATE TABLE audit_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid REFERENCES organizations(id),
 actor_id uuid REFERENCES users(id), entity_type text NOT NULL, entity_id uuid,
 action text NOT NULL, metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now()
);
-- CRITICAL: tenant isolation is enforced by the API and RLS policies below.
-- The application DB role MUST NOT have BYPASSRLS or table-owner privileges.
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers FORCE ROW LEVEL SECURITY;
CREATE POLICY customer_tenant ON customers USING (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid)
 WITH CHECK (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid);
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications FORCE ROW LEVEL SECURITY;
CREATE POLICY application_tenant ON applications USING (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid)
 WITH CHECK (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid);
ALTER TABLE application_answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE application_answers FORCE ROW LEVEL SECURITY;
CREATE POLICY answer_tenant ON application_answers USING (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid)
 WITH CHECK (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid);
ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotes FORCE ROW LEVEL SECURITY;
CREATE POLICY quote_tenant ON quotes USING (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid)
 WITH CHECK (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid);
ALTER TABLE policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE policies FORCE ROW LEVEL SECURITY;
CREATE POLICY policy_tenant ON policies USING (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid)
 WITH CHECK (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid);
ALTER TABLE commission_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_events FORCE ROW LEVEL SECURITY;
CREATE POLICY commission_tenant ON commission_events USING (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid)
 WITH CHECK (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid);
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents FORCE ROW LEVEL SECURITY;
CREATE POLICY document_tenant ON documents USING (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid)
 WITH CHECK (broker_id = nullif(current_setting('app.broker_id',true),'')::uuid);
