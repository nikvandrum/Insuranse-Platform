# Acceptance criteria and implementation backlog

## P0 — Required before broker pilot
1. Authentication and server-side RBAC; MFA for privileged users.
2. Tenant isolation using database RLS and integration tests with two distinct brokers.
3. Versioned insurance class catalog; legal sign-off before publication.
4. Dynamic questionnaires: visibility, requiredness, types, cross-field validation, and dependency cycle detection.
5. Broker workflow: DRAFT → SUBMITTED → UNDER_REVIEW → QUOTING → OFFERED → ACCEPTED.
6. Broker may request missing information and upload/enter quotes manually.
7. Immutable audit event trail and versioned customer needs assessment.
8. Consent/privacy information and secure document storage with malware scanning.
9. Quote comparison must not use commission percentage as suitability factor.
10. No real insurer binding, payments or automatic policy issuance until approved integrations and legal review.

## P1 — After pilot
- Product-specific insurer adapters and idempotent webhook handling.
- Policy lifecycle, renewals, claims assistance and endorsements.
- Commission reconciliation, reversals, invoice integration.
- AI document extraction with confidence score and human verification.

## Security and legal gates
- Complete RLS policies for ALL tenant-owned tables; segregate audit administration.
- Never trust tenant_id from request body; derive from authenticated authorization context.
- Database role used by API cannot bypass RLS; set tenant context using SET LOCAL in transaction.
- Encrypt sensitive data and restrict health/medical data to dedicated workflows.
- Perform GDPR DPIA screening and define controller/processor responsibilities.
- Review IDD, KZ, DORA applicability, distance selling, document retention, IP assignments.
- Verify broker's current registration, insurer contracts and authority.
- No live commission sharing without legal/accounting review of SaaS fee structure.
