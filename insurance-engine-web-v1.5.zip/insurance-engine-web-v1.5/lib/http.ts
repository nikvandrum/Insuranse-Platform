import {NextResponse} from "next/server";
export const unauthorized=()=>NextResponse.json({error:"Необходим е вход"},{status:401});
export const forbidden=()=>NextResponse.json({error:"Недостатъчни права"},{status:403});
export const badOrigin=()=>NextResponse.json({error:"Невалиден произход на заявката"},{status:403});
export function serverError(e:unknown){console.error("Request failed",e instanceof Error?e.message:"unknown");return NextResponse.json({error:"Вътрешна грешка"},{status:500})}
