import property from "../data/property-questionnaire.json";
import motor from "../data/motor-questionnaire.json";
import universal from "../data/universal-intake.json";
export const questionnaires: Record<string,any> = {property,motor,universal};
export const familyNames: Record<string,string> = {property:"Имущество",motor:"Автомобили",travel:"Пътуване",life:"Живот",health:"Здраве",accident:"Злополука",liability:"Отговорности",transport:"Транспорт",construction:"Строителство",agriculture:"Земеделие",financial:"Финансови рискове",special:"Специализирани"};
export function getQuestionnaire(family:string) {return questionnaires[family] || universal;}
