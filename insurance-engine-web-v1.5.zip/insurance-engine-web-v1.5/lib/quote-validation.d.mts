export function validateQuote(v:any):{ok:boolean;errors:Record<string,string>};
export function comparableQuotes(quotes:any[]):any[];
