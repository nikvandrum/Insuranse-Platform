export type Field = {key:string;type:string;label?:string;options?:string[];required?:boolean;requiredWhen?:unknown;visibleWhen?:unknown;validators?:unknown[]};
export function matches(rule:unknown,answers:Record<string,unknown>):boolean;
export function isVisible(field:Field,answers:Record<string,unknown>):boolean;
export function isRequired(field:Field,answers:Record<string,unknown>):boolean;
export function sanitize(questionnaire:{fields:Field[]},answers:Record<string,unknown>):Record<string,unknown>;
export function validate(questionnaire:{fields:Field[]},answers:Record<string,unknown>):{ok:boolean;errors:Record<string,string>;answers:Record<string,unknown>};
export function isValidEik(value:string):boolean;
export function routeApplication(family:string,answers:Record<string,unknown>):string;
