import {Pool,PoolClient} from "pg";
const g=globalThis as typeof globalThis & {__insurancePool?:Pool};
export function pool(){
 if(!process.env.DATABASE_URL)throw new Error("DATABASE_URL is not configured");
 return g.__insurancePool ??= new Pool({connectionString:process.env.DATABASE_URL,max:10,ssl:process.env.PGSSL==="true"?{rejectUnauthorized:true}:undefined});
}
export type Principal={id:string;tenantId:string;tenantSlug:string;role:"PLATFORM_ADMIN"|"BROKER_ADMIN"|"BROKER_AGENT"|"CUSTOMER";email:string};
export async function scoped<T>(user:Principal,fn:(db:PoolClient)=>Promise<T>):Promise<T>{
 const db=await pool().connect();
 try{
  await db.query("BEGIN");
  await db.query("SELECT set_config('app.tenant_id',$1,true),set_config('app.user_id',$2,true),set_config('app.role',$3,true)",[user.tenantId,user.id,user.role]);
  const result=await fn(db);
  await db.query("COMMIT");return result;
 }catch(e){await db.query("ROLLBACK").catch(()=>{});throw e}
 finally{db.release()}
}
