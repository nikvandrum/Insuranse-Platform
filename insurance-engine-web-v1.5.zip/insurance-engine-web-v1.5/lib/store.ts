import { randomUUID } from "node:crypto";
export type Application = {id:string;tenantId:string;family:string;answers:Record<string,unknown>;status:"SUBMITTED"|"NEEDS_INFO"|"UNDER_REVIEW"|"DECLINED";routing:string;createdAt:string;reviewNote?:string};
// DEMO ONLY: ephemeral memory, cleared on server restart. Not suitable for production or personal data.
const globalStore = globalThis as typeof globalThis & { __demoApplications?:Application[] };
const store = globalStore.__demoApplications ??= [];
export function listApps(tenantId:string){return store.filter(x=>x.tenantId===tenantId)}
export function createApp(input:Omit<Application,"id"|"createdAt">){const x={...input,id:randomUUID(),createdAt:new Date().toISOString()};store.unshift(x);return x}
export function reviewApp(id:string,tenantId:string,status:Application["status"],reviewNote:string){const a=store.find(x=>x.id===id&&x.tenantId===tenantId);if(!a)return null;a.status=status;a.reviewNote=reviewNote;return a}
