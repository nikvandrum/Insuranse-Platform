import {createHmac,randomBytes,scryptSync,timingSafeEqual} from "node:crypto";
import {cookies} from "next/headers";
import {pool,Principal} from "./db";
const COOKIE="insurance_session";
const MAX_AGE=60*60*8;
function secret(){const s=process.env.SESSION_SECRET;if(!s||s.length<32)throw new Error("SESSION_SECRET must be at least 32 characters");return s}
export function hashPassword(password:string,salt=randomBytes(16).toString("hex")){
 return `scrypt:${salt}:${scryptSync(password,salt,64).toString("hex")}`;
}
export function checkPassword(password:string,stored:string){
 const parts=stored.split(":");if(parts.length!==3||parts[0]!=="scrypt")return false;
 const expected=Buffer.from(parts[2],"hex");if(expected.length!==64)return false;
 return timingSafeEqual(expected,scryptSync(password,parts[1],64));
}
function sign(value:string){return createHmac("sha256",secret()).update(value).digest("base64url")}
export function issueSession(user:Principal){
 const payload=Buffer.from(JSON.stringify({id:user.id,tenantId:user.tenantId,exp:Math.floor(Date.now()/1000)+MAX_AGE})).toString("base64url");
 return `${payload}.${sign(payload)}`;
}
export async function setSession(user:Principal){(await cookies()).set(COOKIE,issueSession(user),{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"strict",path:"/",maxAge:MAX_AGE})}
export async function clearSession(){(await cookies()).delete(COOKIE)}
export async function getPrincipal():Promise<Principal|null>{
 const token=(await cookies()).get(COOKIE)?.value;if(!token)return null;
 const [payload,signature,...extra]=token.split(".");if(!payload||!signature||extra.length)return null;
 const actual=Buffer.from(signature),expected=Buffer.from(sign(payload));
 if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return null;
 let data:{id:string;tenantId:string;exp:number};try{data=JSON.parse(Buffer.from(payload,"base64url").toString("utf8"))}catch{return null}
 if(!data.id||!data.tenantId||!Number.isSafeInteger(data.exp)||data.exp<Math.floor(Date.now()/1000))return null;
 const result=await pool().query(`SELECT u.id,u.tenant_id AS "tenantId",u.email,u.role,t.slug AS "tenantSlug"
 FROM app_users u JOIN tenants t ON t.id=u.tenant_id
 WHERE u.id=$1 AND u.tenant_id=$2 AND u.active AND t.active`,[data.id,data.tenantId]);
 return (result.rows[0] as Principal)||null;
}
export function sameOrigin(req:Request){
 const origin=req.headers.get("origin");const host=req.headers.get("host");
 if(!origin||!host)return false;
 try{const u=new URL(origin);return u.host===host&&(u.protocol==="https:"||(process.env.NODE_ENV!=="production"&&u.protocol==="http:"))}catch{return false}
}
