# INSURE PLATFORM v1.5 — pilot hardening and payment plan engine

Надгражда v1.4 с детерминистичен калкулатор на вноски (без тарифиране), проектна SQL миграция за планове и метаданни на документи и чеклист за защитен пилот. **Не е продукционно готово**.

Вижте `docs/PILOT_SECURITY_BG.md` и `docs/DEPLOYMENT_BG.md`.

`npm test` проверява логиката без външни зависимости.
