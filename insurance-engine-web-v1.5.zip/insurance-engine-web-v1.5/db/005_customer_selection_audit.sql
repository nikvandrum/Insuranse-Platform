-- Customer may write only a self-attributed quote selection audit event.
-- Scope tenant and ownership of selected quote via application.
DROP POLICY IF EXISTS audit_customer_quote_selection ON audit_events;
CREATE POLICY audit_customer_quote_selection ON audit_events FOR INSERT WITH CHECK (
 tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid
 AND actor_user_id=NULLIF(current_setting('app.user_id',true),'')::uuid
 AND current_setting('app.role',true)='CUSTOMER'
 AND entity_type='quote' AND action='CUSTOMER_SELECTED'
 AND EXISTS (SELECT 1 FROM quotes q JOIN applications a ON a.id=q.application_id AND a.tenant_id=q.tenant_id
 WHERE q.id=entity_id AND q.tenant_id=tenant_id AND a.customer_user_id=actor_user_id)
);
-- A customer may mark only their own PRESENTED quote as SELECTED.
-- Column-level UPDATE(status) grant is required for the runtime DB role;
-- avoid unrestricted UPDATE privileges on quotes.
DROP POLICY IF EXISTS quotes_customer_selection ON quotes;
CREATE POLICY quotes_customer_selection ON quotes FOR UPDATE
 USING (
 tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid
 AND current_setting('app.role',true)='CUSTOMER'
 AND status='PRESENTED'
 AND EXISTS (SELECT 1 FROM applications a WHERE a.id=application_id
 AND a.tenant_id=tenant_id AND a.customer_user_id=NULLIF(current_setting('app.user_id',true),'')::uuid)
 )
 WITH CHECK (
 tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid
 AND current_setting('app.role',true)='CUSTOMER'
 AND status='SELECTED'
 AND EXISTS (SELECT 1 FROM applications a WHERE a.id=application_id
 AND a.tenant_id=tenant_id AND a.customer_user_id=NULLIF(current_setting('app.user_id',true),'')::uuid)
 );
