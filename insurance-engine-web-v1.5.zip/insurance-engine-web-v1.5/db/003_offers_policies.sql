-- Apply as database owner. Runtime role must not own these tables or bypass RLS.
CREATE TABLE IF NOT EXISTS insurers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, code text UNIQUE NOT NULL
);
CREATE TABLE IF NOT EXISTS quotes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 application_id uuid NOT NULL REFERENCES applications(id), insurer_id uuid NOT NULL REFERENCES insurers(id),
 premium_cents bigint NOT NULL CHECK(premium_cents > 0), currency char(3) NOT NULL DEFAULT 'EUR' CHECK(currency='EUR'),
 valid_until date NOT NULL, coverage jsonb NOT NULL, exclusions text NOT NULL DEFAULT '',
 deductible text NOT NULL DEFAULT '', source_reference text NOT NULL,
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','PRESENTED','WITHDRAWN','SELECTED')),
 created_by uuid NOT NULL REFERENCES app_users(id), created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS idx_quotes_application ON quotes(tenant_id,application_id);
CREATE TABLE IF NOT EXISTS policies (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 application_id uuid NOT NULL REFERENCES applications(id), quote_id uuid NOT NULL,
 policy_number text NOT NULL, issued_at timestamptz NOT NULL,
 starts_on date NOT NULL, ends_on date NOT NULL, document_reference text NOT NULL,
 recorded_by uuid NOT NULL REFERENCES app_users(id), created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(ends_on>starts_on), UNIQUE(tenant_id,policy_number), UNIQUE(quote_id),
 FOREIGN KEY(quote_id,tenant_id) REFERENCES quotes(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS idx_policies_renewal ON policies(tenant_id,ends_on);
ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotes FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS quotes_tenant ON quotes;
CREATE POLICY quotes_tenant ON quotes FOR ALL USING (
 tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND
 (current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT') OR
 EXISTS(SELECT 1 FROM applications a WHERE a.id=application_id AND a.customer_user_id=NULLIF(current_setting('app.user_id',true),'')::uuid AND quotes.status IN ('PRESENTED','SELECTED'))))
 WITH CHECK(tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'));
ALTER TABLE policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE policies FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS policies_tenant ON policies;
CREATE POLICY policies_tenant ON policies FOR ALL USING (
 tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND
 (current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT') OR
 EXISTS(SELECT 1 FROM applications a WHERE a.id=application_id AND a.customer_user_id=NULLIF(current_setting('app.user_id',true),'')::uuid)))
 WITH CHECK(tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'));
-- Database trigger prevents cross-tenant quote/application links even if application code is faulty.
CREATE OR REPLACE FUNCTION enforce_quote_application_tenant() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM applications WHERE id=NEW.application_id AND tenant_id=NEW.tenant_id) THEN
  RAISE EXCEPTION 'Quote application tenant mismatch';
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS quote_tenant_guard ON quotes;
CREATE TRIGGER quote_tenant_guard BEFORE INSERT OR UPDATE ON quotes FOR EACH ROW EXECUTE FUNCTION enforce_quote_application_tenant();
CREATE OR REPLACE FUNCTION enforce_policy_links() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM quotes q WHERE q.id=NEW.quote_id AND q.tenant_id=NEW.tenant_id AND q.application_id=NEW.application_id AND q.status='SELECTED') THEN
  RAISE EXCEPTION 'Policy quote link invalid';
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS policy_links_guard ON policies;
CREATE TRIGGER policy_links_guard BEFORE INSERT OR UPDATE ON policies FOR EACH ROW EXECUTE FUNCTION enforce_policy_links();
