-- TEST DATA ONLY. Replace with verified insurer catalog before production.
INSERT INTO insurers(code,name) VALUES ('TEST_INS_A','Демо застраховател А'),('TEST_INS_B','Демо застраховател Б') ON CONFLICT(code) DO NOTHING;
