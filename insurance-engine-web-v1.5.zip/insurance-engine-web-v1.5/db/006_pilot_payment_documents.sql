-- Apply using DB owner, not runtime account. Never use superuser/BYPASSRLS for API.
CREATE TABLE IF NOT EXISTS quote_payment_plans (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 quote_id uuid NOT NULL, source text NOT NULL CHECK(source IN ('INSURER_API','INSURER_DOCUMENT','BROKER_VERIFIED')),
 currency char(3) NOT NULL DEFAULT 'EUR', total_cents bigint NOT NULL CHECK(total_cents>=0),
 status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','BROKER_APPROVED','WITHDRAWN')),
 created_by uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(created_by,tenant_id) REFERENCES app_users(id,tenant_id),
 UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS quote_installments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES tenants(id),
 plan_id uuid NOT NULL,sequence_no int NOT NULL CHECK(sequence_no>0),
 due_date date NOT NULL,amount_cents bigint NOT NULL CHECK(amount_cents>=0),
 payment_status text NOT NULL DEFAULT 'UNPAID' CHECK(payment_status IN ('UNPAID','PAID','PARTIAL','OVERDUE','CANCELLED')),
 FOREIGN KEY(plan_id,tenant_id) REFERENCES quote_payment_plans(id,tenant_id),
 UNIQUE(plan_id,sequence_no)
);
CREATE TABLE IF NOT EXISTS secure_documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES tenants(id),
 application_id uuid NOT NULL, uploaded_by uuid NOT NULL,
 object_key text NOT NULL UNIQUE, original_name text NOT NULL,
 mime_type text NOT NULL,byte_size bigint NOT NULL CHECK(byte_size>0 AND byte_size<=20971520),
 sha256 char(64) NOT NULL,scan_status text NOT NULL DEFAULT 'PENDING' CHECK(scan_status IN ('PENDING','CLEAN','REJECTED')),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(uploaded_by,tenant_id) REFERENCES app_users(id,tenant_id)
);
DO $$ DECLARE tab text; BEGIN
 FOREACH tab IN ARRAY ARRAY['quote_payment_plans','quote_installments','secure_documents'] LOOP
 EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY',tab);
 EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY',tab);
 EXECUTE format('CREATE POLICY %I ON %I FOR ALL USING (tenant_id = NULLIF(current_setting(''app.tenant_id'',true),)::uuid AND current_setting(app.role,true) IN (BROKER_ADMIN,BROKER_AGENT)) WITH CHECK (tenant_id = NULLIF(current_setting(app.tenant_id,true),)::uuid AND current_setting(''app.role'',true) IN (''BROKER_ADMIN'',''BROKER_AGENT''))',tab||'_tenant',tab);
 END LOOP;
END $$;
-- Required before deployment: add composite tenant-aware FKs from quote_id/application_id to existing tables;
-- verify actual existing table names and columns in migrations 003/005. No runtime write grants until reviewed.
