-- Run as database owner, not as the runtime application user.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS tenants (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), slug text UNIQUE NOT NULL,
 name text NOT NULL, eik varchar(13) UNIQUE NOT NULL, kind text NOT NULL CHECK(kind IN ('PLATFORM','BROKER')),
 active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS app_users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 email text NOT NULL, password_hash text NOT NULL,
 role text NOT NULL CHECK(role IN ('PLATFORM_ADMIN','BROKER_ADMIN','BROKER_AGENT','CUSTOMER')),
 active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(tenant_id,email), UNIQUE(id,tenant_id)
);
CREATE TABLE IF NOT EXISTS applications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 customer_user_id uuid NOT NULL, family text NOT NULL,
 answers jsonb NOT NULL, status text NOT NULL DEFAULT 'SUBMITTED'
 CHECK(status IN ('SUBMITTED','UNDER_REVIEW','NEEDS_INFO','DECLINED')),
 routing text NOT NULL, review_note text NOT NULL DEFAULT '',
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(customer_user_id,tenant_id) REFERENCES app_users(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS idx_apps_tenant_created ON applications(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_apps_customer ON applications(customer_user_id,created_at DESC);
CREATE TABLE IF NOT EXISTS audit_events (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, tenant_id uuid NOT NULL REFERENCES tenants(id),
 actor_user_id uuid NOT NULL, entity_type text NOT NULL, entity_id uuid NOT NULL,
 action text NOT NULL, details jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_tenant_created ON audit_events(tenant_id,created_at DESC);
-- RLS is a defense-in-depth measure. API also checks roles and ownership.
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS applications_tenant_access ON applications;
CREATE POLICY applications_tenant_access ON applications FOR ALL
 USING (tenant_id = NULLIF(current_setting('app.tenant_id',true),'')::uuid
 AND (current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT')
 OR customer_user_id = NULLIF(current_setting('app.user_id',true),'')::uuid))
 WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id',true),'')::uuid
 AND (current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT')
 OR customer_user_id = NULLIF(current_setting('app.user_id',true),'')::uuid));
DROP POLICY IF EXISTS audit_tenant_access ON audit_events;
CREATE POLICY audit_tenant_access ON audit_events FOR ALL
 USING (tenant_id = NULLIF(current_setting('app.tenant_id',true),'')::uuid
 AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'))
 WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id',true),'')::uuid
 AND NULLIF(current_setting('app.user_id',true),'')::uuid = actor_user_id);
-- Use separate, non-owner DB role for runtime. Do not grant BYPASSRLS.
INSERT INTO tenants(slug,name,eik,kind) VALUES
 ('lucky-star-08','Лъки Стар – 08 ЕООД','200339166','PLATFORM'),
 ('ap-brokers-207717424','ЕЙ ПИ БРОКЕРС ООД','207717424','BROKER')
 ON CONFLICT(slug) DO NOTHING;
