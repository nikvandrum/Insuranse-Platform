# Локален старт и проверка

```bash
cp .env.example .env.local
npm ci
npm test
npm run build
# В изолирана PostgreSQL среда, с отделен migration owner:
npm run db:migrate
npm run dev
```

**Внимание:** миграцията 006 е проектна и изисква review на FK към реалните quote/application таблици, преди изпълнение. Не стартирайте публичен сървър с реални данни. При липса на `package-lock.json` използвайте `npm install` в контролирана среда, прегледайте и commit-нете lockfile, след което използвайте `npm ci` в CI.
