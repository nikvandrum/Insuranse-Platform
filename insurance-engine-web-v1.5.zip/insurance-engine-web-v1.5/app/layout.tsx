import "./style.css";
export const metadata = { title: "Insurance Engine · Лъки Стар – 08", description: "Демонстрационна застрахователна платформа" };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="bg"><body>{children}</body></html> }
