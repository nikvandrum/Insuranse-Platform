import {NextRequest,NextResponse} from "next/server";
import {getPrincipal,sameOrigin} from "../../../../lib/auth";
import {scoped} from "../../../../lib/db";
import {badOrigin,forbidden,serverError,unauthorized} from "../../../../lib/http";
export async function PATCH(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 if(!sameOrigin(req))return badOrigin();
 try{
 const u=await getPrincipal();if(!u)return unauthorized();if(!["BROKER_ADMIN","BROKER_AGENT"].includes(u.role))return forbidden();
 const {id}=await params;if(!/^[0-9a-f-]{36}$/i.test(id))return NextResponse.json({error:"Невалиден идентификатор"},{status:400});
 const body=await req.json();if(!["UNDER_REVIEW","NEEDS_INFO","DECLINED"].includes(body?.status)||typeof body.reviewNote!=="string"||body.reviewNote.length>1000)return NextResponse.json({error:"Невалидна промяна"},{status:400});
 const item=await scoped(u,async db=>{
 const r=await db.query(`UPDATE applications SET status=$1,review_note=$2,updated_at=now() WHERE id=$3 AND tenant_id=$4 AND status IN ('SUBMITTED','UNDER_REVIEW','NEEDS_INFO') RETURNING id,status,review_note AS "reviewNote"`,[body.status,body.reviewNote,id,u.tenantId]);
 if(!r.rowCount)return null;
 await db.query(`INSERT INTO audit_events(tenant_id,actor_user_id,entity_type,entity_id,action,details) VALUES($1,$2,'application',$3,'STATUS_CHANGED',$4::jsonb)`,[u.tenantId,u.id,id,JSON.stringify({status:body.status})]);return r.rows[0]
 });return item?NextResponse.json({item}):NextResponse.json({error:"Заявката не е намерена или е приключена"},{status:404});
 }catch(e){return serverError(e)}
}
