import {NextResponse} from "next/server";
import {getPrincipal} from "../../../../../lib/auth";
import {scoped} from "../../../../../lib/db";
import {forbidden,serverError,unauthorized} from "../../../../../lib/http";
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){try{const u=await getPrincipal();if(!u)return unauthorized();if(u.role==="PLATFORM_ADMIN")return forbidden();const {id}=await params;if(!uuid.test(id))return NextResponse.json({error:"Invalid ID"},{status:400});const policies=await scoped(u,async db=>(await db.query(`SELECT p.id,p.policy_number AS "policyNumber",p.starts_on AS "startsOn",p.ends_on AS "endsOn",p.document_reference AS "documentReference",i.name AS insurer,q.premium_cents AS "premiumCents" FROM policies p JOIN quotes q ON q.id=p.quote_id AND q.tenant_id=p.tenant_id JOIN insurers i ON i.id=q.insurer_id WHERE p.application_id=$1 AND p.tenant_id=$2 ORDER BY p.created_at DESC`,[id,u.tenantId])).rows);return NextResponse.json({policies},{headers:{"Cache-Control":"no-store"}})}catch(e){return serverError(e)}}
