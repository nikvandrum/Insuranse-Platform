import {NextRequest,NextResponse} from "next/server";
import {getPrincipal,sameOrigin} from "../../../../../lib/auth";
import {scoped} from "../../../../../lib/db";
import {badOrigin,forbidden,serverError,unauthorized} from "../../../../../lib/http";
const uuid=/^[0-9a-f-]{36}$/i;
export async function POST(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 if(!sameOrigin(req))return badOrigin();try{const u=await getPrincipal();if(!u)return unauthorized();if(!["BROKER_ADMIN","BROKER_AGENT"].includes(u.role))return forbidden();const {id}=await params;const b=await req.json();
 if(!uuid.test(id)||!uuid.test(b?.quoteId)||typeof b?.policyNumber!=="string"||b.policyNumber.length<2||b.policyNumber.length>80||typeof b?.documentReference!=="string"||b.documentReference.length<3||b.documentReference.length>300||!/^\d{4}-\d{2}-\d{2}$/.test(b?.startsOn||'')||!/^\d{4}-\d{2}-\d{2}$/.test(b?.endsOn||'')||b.endsOn<=b.startsOn)return NextResponse.json({error:"Невалидни данни за полица"},{status:422});
 const policy=await scoped(u,async db=>{const r=await db.query(`INSERT INTO policies(tenant_id,application_id,quote_id,policy_number,issued_at,starts_on,ends_on,document_reference,recorded_by) SELECT $1,$2,q.id,$4,now(),$5,$6,$7,$8 FROM quotes q WHERE q.id=$3 AND q.application_id=$2 AND q.tenant_id=$1 AND q.status='SELECTED' RETURNING id,policy_number AS "policyNumber"`,[u.tenantId,id,b.quoteId,b.policyNumber,b.startsOn,b.endsOn,b.documentReference,u.id]);if(!r.rowCount)return null;
 await db.query(`INSERT INTO audit_events(tenant_id,actor_user_id,entity_type,entity_id,action) VALUES($1,$2,'policy',$3,'RECORDED')`,[u.tenantId,u.id,r.rows[0].id]);return r.rows[0]});
 return policy?NextResponse.json({policy},{status:201}):NextResponse.json({error:"Няма избрана оферта"},{status:409});
 }catch(e){return serverError(e)}
}
