import {NextRequest,NextResponse} from "next/server";
import {getPrincipal,sameOrigin} from "../../../../../lib/auth";
import {scoped} from "../../../../../lib/db";
import {badOrigin,forbidden,serverError,unauthorized} from "../../../../../lib/http";
import {validateQuote} from "../../../../../lib/quote-validation.mjs";
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export async function GET(_req:NextRequest,{params}:{params:Promise<{id:string}>}){
 try{const u=await getPrincipal();if(!u)return unauthorized();if(u.role==="PLATFORM_ADMIN")return forbidden();const {id}=await params;if(!uuid.test(id))return NextResponse.json({error:"Invalid ID"},{status:400});
 const quotes=await scoped(u,async db=>(await db.query(`SELECT q.id,i.name AS insurer,q.premium_cents AS "premiumCents",q.currency,q.valid_until AS "validUntil",q.coverage,q.exclusions,q.deductible,q.status FROM quotes q JOIN insurers i ON i.id=q.insurer_id WHERE q.application_id=$1 AND q.tenant_id=$2 AND (q.status IN ('PRESENTED','SELECTED') OR $3 IN ('BROKER_ADMIN','BROKER_AGENT')) ORDER BY q.premium_cents`,[id,u.tenantId,u.role])).rows);
 return NextResponse.json({quotes},{headers:{"Cache-Control":"no-store"}})}catch(e){return serverError(e)}
}
export async function POST(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 if(!sameOrigin(req))return badOrigin();try{const u=await getPrincipal();if(!u)return unauthorized();if(!["BROKER_ADMIN","BROKER_AGENT"].includes(u.role))return forbidden();const {id}=await params;if(!uuid.test(id))return NextResponse.json({error:"Invalid ID"},{status:400});const body=await req.json();const v=validateQuote(body);if(!v.ok)return NextResponse.json({errors:v.errors},{status:422});
 const quote=await scoped(u,async db=>{const a=await db.query(`SELECT id FROM applications WHERE id=$1 AND tenant_id=$2 AND status IN ('SUBMITTED','UNDER_REVIEW') FOR UPDATE`,[id,u.tenantId]);if(!a.rowCount)return null;
 const i=await db.query(`SELECT id FROM insurers WHERE code=$1`,[body.insurerCode]);if(!i.rowCount)return {missingInsurer:true};
 const r=await db.query(`INSERT INTO quotes(tenant_id,application_id,insurer_id,premium_cents,currency,valid_until,coverage,exclusions,deductible,source_reference,status,created_by) VALUES($1,$2,$3,$4,'EUR',$5,$6::jsonb,$7,$8,$9,'PRESENTED',$10) RETURNING id,status`,[u.tenantId,id,i.rows[0].id,body.premiumCents,body.validUntil,JSON.stringify(body.coverage),body.exclusions,body.deductible,body.sourceReference,u.id]);
 await db.query(`INSERT INTO audit_events(tenant_id,actor_user_id,entity_type,entity_id,action) VALUES($1,$2,'quote',$3,'PRESENTED')`,[u.tenantId,u.id,r.rows[0].id]);return r.rows[0]});
 if(!quote)return NextResponse.json({error:"Заявката не е достъпна"},{status:404});if('missingInsurer' in quote)return NextResponse.json({error:"Няма регистриран застраховател с този код"},{status:422});return NextResponse.json({quote},{status:201});
 }catch(e){return serverError(e)}
}
