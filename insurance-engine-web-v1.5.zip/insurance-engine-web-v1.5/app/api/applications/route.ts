import {NextRequest,NextResponse} from "next/server";
import {getQuestionnaire,familyNames} from "../../../lib/catalog";
import {validate,routeApplication} from "../../../lib/rules.mjs";
import {getPrincipal,sameOrigin} from "../../../lib/auth";
import {scoped} from "../../../lib/db";
import {badOrigin,forbidden,serverError,unauthorized} from "../../../lib/http";
export async function GET(){try{
 const u=await getPrincipal();if(!u)return unauthorized();if(u.role==="PLATFORM_ADMIN")return forbidden();
 const items=await scoped(u,async db=>(await db.query(`SELECT id,tenant_id AS "tenantId",family,answers,status,routing,review_note AS "reviewNote",created_at AS "createdAt" FROM applications ORDER BY created_at DESC LIMIT 100`)).rows);
 return NextResponse.json({items},{headers:{"Cache-Control":"no-store"}});
 }catch(e){return serverError(e)}}
export async function POST(req:NextRequest){
 if(!sameOrigin(req))return badOrigin();
 try{
 const u=await getPrincipal();if(!u)return unauthorized();if(u.role!=="CUSTOMER")return forbidden();
 const body=await req.json();const family=body?.family;
 if(typeof family!=="string"||!Object.hasOwn(familyNames,family))return NextResponse.json({error:"Непознат продукт"},{status:400});
 if(!body?.answers||typeof body.answers!=="object"||Array.isArray(body.answers)||JSON.stringify(body.answers).length>20000)return NextResponse.json({error:"Невалидни отговори"},{status:400});
 const q=getQuestionnaire(family);
 if(!["property","motor"].includes(family)&&body.answers.family_key!==family)return NextResponse.json({error:"Несъответствие в категорията"},{status:422});
 const result=validate(q,body.answers);
 if(!result.ok)return NextResponse.json({error:"Невалидна заявка",fields:result.errors},{status:422});
 const routing=routeApplication(family,result.answers);
 const item=await scoped(u,async db=>{
 const a=(await db.query(`INSERT INTO applications(tenant_id,customer_user_id,family,answers,routing)
 VALUES($1,$2,$3,$4::jsonb,$5) RETURNING id,family,status,routing,created_at AS "createdAt"`,[u.tenantId,u.id,family,JSON.stringify(result.answers),routing])).rows[0];
 await db.query(`INSERT INTO audit_events(tenant_id,actor_user_id,entity_type,entity_id,action) VALUES($1,$2,'application',$3,'CREATED')`,[u.tenantId,u.id,a.id]);return a;
 });return NextResponse.json({item},{status:201});
 }catch(e){return serverError(e)}
}
