import {NextResponse} from "next/server";
import {getPrincipal} from "../../../lib/auth";
import {scoped} from "../../../lib/db";
import {forbidden,serverError,unauthorized} from "../../../lib/http";
export async function GET(){try{const u=await getPrincipal();if(!u)return unauthorized();if(!["BROKER_ADMIN","BROKER_AGENT"].includes(u.role))return forbidden();const insurers=await scoped(u,async db=>(await db.query("SELECT code,name FROM insurers ORDER BY name")).rows);return NextResponse.json({insurers},{headers:{"Cache-Control":"no-store"}})}catch(e){return serverError(e)}}
