import {NextResponse} from "next/server";
import {familyNames} from "../../../lib/catalog";
export async function GET(){return NextResponse.json({families:familyNames})}
