import {NextRequest,NextResponse} from "next/server";
import {clearSession,sameOrigin} from "../../../../lib/auth";
import {badOrigin} from "../../../../lib/http";
export async function POST(req:NextRequest){if(!sameOrigin(req))return badOrigin();await clearSession();return NextResponse.json({ok:true})}
