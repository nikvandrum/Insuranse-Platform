import {NextResponse} from "next/server";
import {getPrincipal} from "../../../../lib/auth";
import {serverError} from "../../../../lib/http";
export async function GET(){try{const u=await getPrincipal();return NextResponse.json({user:u?{id:u.id,email:u.email,role:u.role,tenantSlug:u.tenantSlug}:null},{headers:{"Cache-Control":"no-store"}})}catch(e){return serverError(e)}}
