import {NextRequest,NextResponse} from "next/server";
import {pool} from "../../../../lib/db";
import {checkPassword,setSession,sameOrigin} from "../../../../lib/auth";
import {badOrigin,serverError} from "../../../../lib/http";
export async function POST(req:NextRequest){
 if(!sameOrigin(req))return badOrigin();
 try{
 const body=await req.json();if(typeof body?.email!=="string"||typeof body?.password!=="string"||typeof body?.tenant!=="string")return NextResponse.json({error:"Невалидни данни"},{status:400});
 if(body.email.length>254||body.password.length>1024||body.tenant.length>100)return NextResponse.json({error:"Невалидни данни"},{status:400});
 const result=await pool().query(`SELECT u.id,u.tenant_id AS "tenantId",u.email,u.role,u.password_hash,t.slug AS "tenantSlug"
 FROM app_users u JOIN tenants t ON t.id=u.tenant_id WHERE lower(u.email)=lower($1) AND t.slug=$2 AND u.active AND t.active`,[body.email.trim(),body.tenant]);
 const user=result.rows[0];if(!user||!checkPassword(body.password,user.password_hash))return NextResponse.json({error:"Невалидни данни за вход"},{status:401});
 await setSession(user);return NextResponse.json({user:{id:user.id,email:user.email,role:user.role,tenantSlug:user.tenantSlug}})
 }catch(e){return serverError(e)}
}
