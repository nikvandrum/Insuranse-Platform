import {test} from "node:test";import assert from "node:assert/strict";import {validateQuote,comparableQuotes} from "../lib/quote-validation.mjs";
const sample={insurerCode:"TEST_INS_A",premiumCents:12050,currency:"EUR",validUntil:"2099-01-01",coverage:[{name:"Пожар",limit:"100000 EUR"}],exclusions:"",deductible:"100 EUR",sourceReference:"manual-quote-001"};
test("valid broker quote",()=>assert.equal(validateQuote(sample).ok,true));
test("reject fabricated negative premium",()=>assert.equal(validateQuote({...sample,premiumCents:-1}).ok,false));
test("reject empty coverage",()=>assert.equal(validateQuote({...sample,coverage:[]}).ok,false));
test("reject expired offer",()=>assert.equal(validateQuote({...sample,validUntil:"2020-01-01"}).ok,false));
test("reject missing source provenance",()=>assert.equal(validateQuote({...sample,sourceReference:""}).ok,false));
test("comparison excludes draft quotes",()=>assert.equal(comparableQuotes([{status:"DRAFT"},{status:"PRESENTED",id:"x",premiumCents:10000,coverage:[]}]).length,1));
