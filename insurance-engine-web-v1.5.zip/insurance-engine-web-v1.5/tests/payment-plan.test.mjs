import test from 'node:test';import assert from 'node:assert/strict';import {allocateCents,buildPaymentPlan} from '../lib/payment-plan.mjs';
test('exact cents with uneven division',()=>assert.deepEqual(allocateCents(10000,[1,1,1]),[3334,3333,3333]));
test('custom insurer weights',()=>assert.deepEqual(allocateCents(10000,[50,30,20]),[5000,3000,2000]));
test('zero total',()=>assert.deepEqual(allocateCents(0,[1,1]),[0,0]));
test('reject negative',()=>assert.throws(()=>allocateCents(-1,[1])));
test('reject unverified source',()=>assert.throws(()=>buildPaymentPlan({premiumCents:100,installments:1,dueDates:['2026-11-01'],source:'DEMO',quoteId:'q'})));
test('reject duplicate due dates',()=>assert.throws(()=>buildPaymentPlan({premiumCents:100,installments:2,dueDates:['2026-11-01','2026-11-01'],source:'BROKER_VERIFIED',quoteId:'q'})));
test('preserve quote provenance',()=>{const p=buildPaymentPlan({premiumCents:48000,installments:4,dueDates:['2026-11-01','2027-02-01','2027-05-01','2027-08-01'],source:'INSURER_DOCUMENT',quoteId:'q-1'});assert.equal(p.installments.reduce((a,b)=>a+b.amountCents,0),48000);assert.equal(p.quoteId,'q-1')});
