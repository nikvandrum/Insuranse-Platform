import {randomBytes,scryptSync} from "node:crypto";
import pg from "pg";
const [,,tenantSlug,email,role]=process.argv;
const roles={"lucky-star-08":["PLATFORM_ADMIN"],"ap-brokers-207717424":["BROKER_ADMIN","BROKER_AGENT","CUSTOMER"]};
if(!roles[tenantSlug]?.includes(role)||!email?.includes("@")||!process.env.DATABASE_ADMIN_URL){
 console.error("Usage: DATABASE_ADMIN_URL=... node scripts/create-user.mjs <tenant-slug> <email> <role>");process.exit(1)
}
const password=process.env.NEW_USER_PASSWORD;
if(!password||password.length<14){console.error("Set NEW_USER_PASSWORD (at least 14 characters) in environment");process.exit(1)}
const salt=randomBytes(16).toString("hex"),hash=`scrypt:${salt}:${scryptSync(password,salt,64).toString("hex")}`;
const db=new pg.Client({connectionString:process.env.DATABASE_ADMIN_URL});
try{await db.connect();const r=await db.query(`INSERT INTO app_users(tenant_id,email,password_hash,role) SELECT id,$1,$2,$3 FROM tenants WHERE slug=$4 RETURNING id`,[email.toLowerCase(),hash,role,tenantSlug]);if(!r.rowCount)throw Error("Unknown tenant");console.log(`User created: ${r.rows[0].id}`)}finally{await db.end()}
