# INSURE PLATFORM v1.4 — UI for quotes, comparison and policies

Owner/operator: Lucky Star – 08 EOOD. First broker: AP Brokers OOD. **Development pilot only, use synthetic data.**

## New
- Broker UI to enter a real insurer quote and its coverage/exclusions/deductible/source reference.
- Customer UI to compare presented quotes and select one (selection is not issuance).
- Broker UI to register an externally issued policy; customer UI to view recorded policy.
- Read-only insurer registry and policy listing endpoints.
- Migration 005: allows customer's self-attributed quote selection audit record.

## Start
1. Configure `.env.local` and PostgreSQL with separate DB owner and runtime roles.
2. `npm install`
3. `npm run db:migrate` with `DATABASE_ADMIN_URL` (001,003,005); 002 contains runtime role examples.
4. Load insurer records **only for the test environment**; `db/004_insurer_seed.example.sql` is a synthetic example.
5. Create users using `npm run user:create`; see original docs.
6. `npm test`, `npm run build`, `npm run dev`.

## Critical limitations
- No end-to-end PostgreSQL integration test performed here; run against disposable DB with separate non-owner runtime user.
- No MFA, document upload security, rate limits, consent capture, production privacy review, real insurer integrations or payments.
- `sourceReference` and `documentReference` are text references, not verified uploaded documents.
- Quote comparison is descriptive, **not advice or automated suitability recommendation**.
- The logo and platform name are working concepts, not confirmed registered trademarks.
- Confirm regulatory and privacy obligations before handling real customer information.
