import {NextRequest,NextResponse} from "next/server";
import {getPrincipal,sameOrigin} from "../../../../../lib/auth";
import {scoped} from "../../../../../lib/db";
import {badOrigin,forbidden,serverError,unauthorized} from "../../../../../lib/http";
const uuid=/^[0-9a-f-]{36}$/i;
export async function POST(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 if(!sameOrigin(req))return badOrigin();try{const u=await getPrincipal();if(!u)return unauthorized();if(u.role!=="CUSTOMER")return forbidden();const {id}=await params;const body=await req.json();if(!uuid.test(id)||!uuid.test(body?.quoteId))return NextResponse.json({error:"Невалиден идентификатор"},{status:400});
 const selected=await scoped(u,async db=>{const a=await db.query(`SELECT id FROM applications WHERE id=$1 AND tenant_id=$2 AND customer_user_id=$3 FOR UPDATE`,[id,u.tenantId,u.id]);if(!a.rowCount)return null;
 const q=await db.query(`UPDATE quotes SET status='SELECTED' WHERE id=$1 AND application_id=$2 AND tenant_id=$3 AND status='PRESENTED' AND valid_until>=CURRENT_DATE RETURNING id`,[body.quoteId,id,u.tenantId]);if(!q.rowCount)return null;
 await db.query(`UPDATE quotes SET status='WITHDRAWN' WHERE application_id=$1 AND tenant_id=$2 AND id<>$3 AND status='PRESENTED'`,[id,u.tenantId,body.quoteId]);
 await db.query(`INSERT INTO audit_events(tenant_id,actor_user_id,entity_type,entity_id,action) VALUES($1,$2,'quote',$3,'CUSTOMER_SELECTED')`,[u.tenantId,u.id,body.quoteId]);return q.rows[0]});
 return selected?NextResponse.json({selected}):NextResponse.json({error:"Няма налична валидна оферта"},{status:404});
 }catch(e){return serverError(e)}
}
