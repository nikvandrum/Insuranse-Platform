import {NextResponse} from "next/server";
import {familyNames,questionnaires} from "../../../lib/catalog";
export async function GET(){return NextResponse.json({families:familyNames,questionnaires:Object.keys(questionnaires)})}
