import {NextRequest,NextResponse} from "next/server";
import {getQuestionnaire,familyNames} from "../../../lib/catalog";
import {createApp,listApps} from "../../../lib/store";
import {validate,routeApplication} from "../../../lib/rules.mjs";
const TENANT="ap-brokers-207717424";
export async function GET(){return NextResponse.json({items:listApps(TENANT)})}
export async function POST(req:NextRequest){
 let body:any;try{body=await req.json()}catch{return NextResponse.json({error:"Невалиден JSON"},{status:400})}
 const family=body?.family;
 if(typeof family!=="string"||!familyNames[family])return NextResponse.json({error:"Непознат продукт"},{status:400});
 if(!body?.answers||typeof body.answers!=="object"||Array.isArray(body.answers))return NextResponse.json({error:"Липсват отговори"},{status:400});
 const q=getQuestionnaire(family);if(!["property","motor"].includes(family) && body.answers.family_key!==family)return NextResponse.json({error:"Несъответствие в категорията"},{status:422});const result=validate(q,body.answers);
 if(!result.ok)return NextResponse.json({error:"Невалидна заявка",fields:result.errors},{status:422});
 const app=createApp({tenantId:TENANT,family,answers:result.answers,status:"SUBMITTED",routing:routeApplication(family,result.answers)});
 return NextResponse.json({item:app},{status:201});
}
