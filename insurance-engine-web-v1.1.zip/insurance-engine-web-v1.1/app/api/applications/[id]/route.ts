import {NextRequest,NextResponse} from "next/server";
import {reviewApp} from "../../../../lib/store";
const TENANT="ap-brokers-207717424";
export async function PATCH(req:NextRequest,{params}:{params:Promise<{id:string}>}){
 const {id}=await params;let body:any;try{body=await req.json()}catch{return NextResponse.json({error:"Невалиден JSON"},{status:400})}
 if(!["UNDER_REVIEW","NEEDS_INFO","DECLINED"].includes(body?.status))return NextResponse.json({error:"Невалиден статус"},{status:400});
 const item=reviewApp(id,TENANT,body.status,String(body.reviewNote||"").slice(0,1000));
 return item?NextResponse.json({item}):NextResponse.json({error:"Не е намерена заявка"},{status:404});
}
