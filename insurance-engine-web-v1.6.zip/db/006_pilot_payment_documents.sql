-- v1.6: tenant-scoped payment schedules and secure document metadata.
-- Apply as schema owner. Runtime role must not own tables or have BYPASSRLS.
ALTER TABLE applications ADD CONSTRAINT applications_id_tenant_unique UNIQUE (id,tenant_id);
CREATE TABLE IF NOT EXISTS quote_payment_plans (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id),
 quote_id uuid NOT NULL, source text NOT NULL CHECK(source IN ('INSURER_API','INSURER_DOCUMENT','BROKER_VERIFIED')),
 source_reference text NOT NULL CHECK(length(trim(source_reference))>0),
 currency char(3) NOT NULL DEFAULT 'EUR' CHECK(currency='EUR'),
 total_cents bigint NOT NULL CHECK(total_cents>0),
 status text NOT NULL DEFAULT 'BROKER_APPROVED' CHECK(status IN ('DRAFT','BROKER_APPROVED','WITHDRAWN')),
 created_by uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(created_by,tenant_id) REFERENCES app_users(id,tenant_id),
 FOREIGN KEY(quote_id,tenant_id) REFERENCES quotes(id,tenant_id), UNIQUE(id,tenant_id)
);
CREATE INDEX IF NOT EXISTS idx_payment_plans_quote ON quote_payment_plans(tenant_id,quote_id);
CREATE TABLE IF NOT EXISTS quote_installments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES tenants(id),
 plan_id uuid NOT NULL,sequence_no int NOT NULL CHECK(sequence_no>0),
 due_date date NOT NULL,amount_cents bigint NOT NULL CHECK(amount_cents>=0),
 payment_status text NOT NULL DEFAULT 'UNPAID' CHECK(payment_status IN ('UNPAID','PAID','PARTIAL','OVERDUE','CANCELLED')),
 FOREIGN KEY(plan_id,tenant_id) REFERENCES quote_payment_plans(id,tenant_id),
 UNIQUE(plan_id,sequence_no)
);
CREATE TABLE IF NOT EXISTS secure_documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),tenant_id uuid NOT NULL REFERENCES tenants(id),
 application_id uuid NOT NULL, uploaded_by uuid NOT NULL,
 object_key text NOT NULL UNIQUE, original_name text NOT NULL,
 mime_type text NOT NULL,byte_size bigint NOT NULL CHECK(byte_size>0 AND byte_size<=20971520),
 sha256 char(64) NOT NULL,scan_status text NOT NULL DEFAULT 'PENDING' CHECK(scan_status IN ('PENDING','CLEAN','REJECTED')),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(uploaded_by,tenant_id) REFERENCES app_users(id,tenant_id),
 FOREIGN KEY(application_id,tenant_id) REFERENCES applications(id,tenant_id)
);
-- Required to support tenant-safe foreign key on application.

ALTER TABLE quote_payment_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_payment_plans FORCE ROW LEVEL SECURITY;
ALTER TABLE quote_installments ENABLE ROW LEVEL SECURITY;
ALTER TABLE quote_installments FORCE ROW LEVEL SECURITY;
ALTER TABLE secure_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE secure_documents FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS payment_plan_access ON quote_payment_plans;
CREATE POLICY payment_plan_access ON quote_payment_plans FOR SELECT USING (
 tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND
 (current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT') OR
 (status='BROKER_APPROVED' AND EXISTS(
 SELECT 1 FROM quotes q JOIN applications a ON a.id=q.application_id
 WHERE q.id=quote_id AND q.tenant_id=quote_payment_plans.tenant_id
 AND q.status IN ('PRESENTED','SELECTED')
 AND a.customer_user_id=NULLIF(current_setting('app.user_id',true),'')::uuid)))) ;
CREATE POLICY payment_plan_broker_write ON quote_payment_plans FOR ALL
 USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'))
 WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'));
DROP POLICY IF EXISTS installment_access ON quote_installments;
CREATE POLICY installment_access ON quote_installments FOR SELECT USING (
 tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND EXISTS(
 SELECT 1 FROM quote_payment_plans p WHERE p.id=plan_id AND p.tenant_id=quote_installments.tenant_id));
CREATE POLICY installment_broker_write ON quote_installments FOR ALL
 USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'))
 WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'));
DROP POLICY IF EXISTS documents_broker_only ON secure_documents;
CREATE POLICY documents_broker_only ON secure_documents FOR ALL
 USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'))
 WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid AND current_setting('app.role',true) IN ('BROKER_ADMIN','BROKER_AGENT'));
