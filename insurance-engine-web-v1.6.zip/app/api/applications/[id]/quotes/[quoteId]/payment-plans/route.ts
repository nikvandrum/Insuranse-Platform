import {NextRequest,NextResponse} from "next/server";
import {getPrincipal,sameOrigin} from "../../../../../../../lib/auth";
import {scoped} from "../../../../../../../lib/db";
import {badOrigin,forbidden,serverError,unauthorized} from "../../../../../../../lib/http";
import {buildPaymentPlan} from "../../../../../../../lib/payment-plan.mjs";
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
type Ctx={params:Promise<{id:string;quoteId:string}>};
export async function GET(_req:NextRequest,{params}:Ctx){
 try {const u=await getPrincipal();if(!u)return unauthorized();if(u.role==='PLATFORM_ADMIN')return forbidden();
 const {id,quoteId}=await params;if(!uuid.test(id)||!uuid.test(quoteId))return NextResponse.json({error:'Invalid ID'},{status:400});
 const plans=await scoped(u,async db=>{
 const quote=await db.query('SELECT id FROM quotes WHERE id=$1 AND application_id=$2 AND tenant_id=$3',[quoteId,id,u.tenantId]);if(!quote.rowCount)return null;
 const p=await db.query(`SELECT id,total_cents AS "totalCents",currency,source,source_reference AS "sourceReference",status,created_at AS "createdAt" FROM quote_payment_plans WHERE quote_id=$1 AND tenant_id=$2 AND (status='BROKER_APPROVED' OR $3 IN ('BROKER_ADMIN','BROKER_AGENT')) ORDER BY created_at DESC`,[quoteId,u.tenantId,u.role]);
 const result=[];for(const plan of p.rows){const r=await db.query(`SELECT sequence_no AS "number",due_date::text AS "dueDate",amount_cents AS "amountCents",payment_status AS "paymentStatus" FROM quote_installments WHERE plan_id=$1 AND tenant_id=$2 ORDER BY sequence_no`,[plan.id,u.tenantId]);result.push({...plan,installments:r.rows})}return result;
 });if(plans===null)return NextResponse.json({error:'Quote not found'},{status:404});return NextResponse.json({plans},{headers:{'Cache-Control':'no-store'}});
 }catch(e){return serverError(e)}
}
export async function POST(req:NextRequest,{params}:Ctx){
 if(!sameOrigin(req))return badOrigin();
 try {const u=await getPrincipal();if(!u)return unauthorized();if(!['BROKER_ADMIN','BROKER_AGENT'].includes(u.role))return forbidden();
 const {id,quoteId}=await params;if(!uuid.test(id)||!uuid.test(quoteId))return NextResponse.json({error:'Invalid ID'},{status:400});
 const body=await req.json();if(typeof body.sourceReference!=='string'||body.sourceReference.trim().length<3||body.sourceReference.length>300)return NextResponse.json({error:'Изисква се референция към потвърдените условия на застрахователя'},{status:422});
 const source=body.source;let schedule;try{schedule=buildPaymentPlan({premiumCents:body.totalCents,installments:body.dueDates?.length,dueDates:body.dueDates,weights:body.weights,source,quoteId,currency:'EUR'});}catch(e){return NextResponse.json({error:(e as Error).message},{status:422})}
 if(schedule.totalCents<=0)return NextResponse.json({error:'Invalid premium'},{status:422});
 const created=await scoped(u,async db=>{
 const q=await db.query(`SELECT id,premium_cents AS "premiumCents",status FROM quotes WHERE id=$1 AND application_id=$2 AND tenant_id=$3 AND status IN ('PRESENTED','SELECTED') FOR UPDATE`,[quoteId,id,u.tenantId]);if(!q.rowCount)return null;
 // Total can differ from the one-off quote ONLY when supported by verified insurer terms.
 if(schedule.totalCents!==Number(q.rows[0].premiumCents)&&source==='BROKER_VERIFIED'&&!body.confirmDifferentTotal)return {requiresConfirmation:true};
 const p=await db.query(`INSERT INTO quote_payment_plans(tenant_id,quote_id,source,source_reference,total_cents,status,created_by) VALUES($1,$2,$3,$4,$5,'BROKER_APPROVED',$6) RETURNING id`,[u.tenantId,quoteId,source,body.sourceReference.trim(),schedule.totalCents,u.id]);
 for(const item of schedule.installments)await db.query(`INSERT INTO quote_installments(tenant_id,plan_id,sequence_no,due_date,amount_cents) VALUES($1,$2,$3,$4,$5)`,[u.tenantId,p.rows[0].id,item.number,item.dueDate,item.amountCents]);
 await db.query(`INSERT INTO audit_events(tenant_id,actor_user_id,entity_type,entity_id,action,details) VALUES($1,$2,'payment_plan',$3,'BROKER_APPROVED',$4::jsonb)`,[u.tenantId,u.id,p.rows[0].id,JSON.stringify({quoteId,source,sourceReference:body.sourceReference})]);
 return {id:p.rows[0].id,...schedule};
 });if(created===null)return NextResponse.json({error:'Quote not found or not presented'},{status:404});if('requiresConfirmation' in created)return NextResponse.json({error:'Потвърдете изрично различната обща премия според условията на застрахователя'},{status:422});return NextResponse.json({plan:created},{status:201});
 }catch(e){return serverError(e)}
}
