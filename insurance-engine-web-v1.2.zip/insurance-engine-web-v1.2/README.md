# Insurance Engine v1.2 — Secure Pilot

**Owner/operator:** Лъки Стар – 08 ЕООД (EIK 200339166). **First broker tenant:** ЕЙ ПИ БРОКЕРС ООД (EIK 207717424).

## Included
- Next.js 15 / TypeScript client, broker, owner portals, role-specific access
- PostgreSQL persistent applications and audit events
- Tenant-scoped SQL transactions and PostgreSQL FORCE ROW LEVEL SECURITY on applications and audit events
- Password authentication (scrypt), signed HttpOnly SameSite=Strict session cookies, 8-hour expiry, server-side user revalidation
- Origin validation for state-changing API requests, backend authorization checks
- Reused v1.1 catalog and questionnaire/rules engine; tests

## Setup
1. Create PostgreSQL database `insurance_engine` and an **owner/migration** DB user.
2. Copy `.env.example` to `.env.local`, fill `DATABASE_ADMIN_URL`, `DATABASE_URL`, and a random `SESSION_SECRET` (>=32 chars). Never commit secrets.
3. `npm install`
4. `DATABASE_ADMIN_URL=... npm run db:migrate`
5. As DB administrator, create a **separate runtime role** with NO `BYPASSRLS` and NO table ownership. Follow `db/002_runtime_role.example.sql`, granting runtime permissions. Runtime and migration DB URLs must differ.
6. Provision users using `NEW_USER_PASSWORD='a-unique-long-password' DATABASE_ADMIN_URL=... npm run user:create -- ap-brokers-207717424 broker@example.test BROKER_ADMIN`. Provision CUSTOMER similarly, and PLATFORM_ADMIN under lucky-star-08.
7. `npm run dev`; open `http://localhost:3000`. `npm test` for unit/static tests.

## Security / operational limitations
**NOT production-ready.** No email verification, password reset, MFA, login rate-limiting, secure invitation workflow, customer self-registration, encrypted document storage, insurer integrations, policy issuance, commission ledger or production-grade observability. Add them before public launch. Run behind HTTPS and trusted reverse proxy. Audit retention, backups, DPIA, privacy notices and legal review are required. Do not enter real health or identity data.

**Important:** The owner tenant has metadata/admin access in this prototype; it does **not** have a bypass for broker customer data. Audit insert policies allow customer writes while restricting audit reads to broker roles. The DB owner/migration account must never be used by the web runtime. PostgreSQL role and RLS permissions must be verified in integration tests before deployment.

## Files
- `db/001_init.sql` schema and RLS
- `db/002_runtime_role.example.sql` runtime grants template
- `lib/auth.ts`, `lib/db.ts`, `lib/http.ts` auth/database/security
- `app/api/auth/*` authentication
- `app/api/applications/*` persisted applications and broker workflow
- `scripts/migrate.mjs`, `scripts/create-user.mjs` provisioning
- `tests/*` rules and security contract checks
