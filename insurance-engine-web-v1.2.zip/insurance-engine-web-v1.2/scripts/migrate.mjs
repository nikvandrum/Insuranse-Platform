import {readFileSync} from "node:fs";
import pg from "pg";
if(!process.env.DATABASE_ADMIN_URL){console.error("DATABASE_ADMIN_URL is required");process.exit(1)}
const client=new pg.Client({connectionString:process.env.DATABASE_ADMIN_URL});
try{await client.connect();await client.query(readFileSync(new URL("../db/001_init.sql",import.meta.url),"utf8"));console.log("Database schema ready")}finally{await client.end()}
